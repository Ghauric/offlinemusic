Offline Music Android project

Features:
- Offline audio playback
- Android document picker (import multiple audio files)
- Persistent read access to imported audio files
- Simple dark interface

Build APK:
1. Install Android Studio on a PC.
2. Open this folder as a project.
3. Allow Gradle sync (internet required initially).
4. Build > Build APK(s).
5. Debug APK output is typically app/build/outputs/apk/debug/app-debug.apk.

This is an Android native Kotlin UI/media playback project, not a Rust-compiled APK. It is a separate mobile implementation of the offline player idea. Rust Android builds require Android targets/toolchain and packaging setup; those aren't available in this runtime, so I cannot honestly provide a compiled APK here.
