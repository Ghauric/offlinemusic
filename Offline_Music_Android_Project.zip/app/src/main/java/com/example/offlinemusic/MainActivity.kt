package com.example.offlinemusic

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.view.Gravity
import android.widget.*
import android.graphics.Color

class MainActivity : Activity() {
    private var player: MediaPlayer? = null
    private val tracks = mutableListOf<Uri>()
    private lateinit var list: LinearLayout
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 35, 28, 28)
            setBackgroundColor(Color.rgb(18, 20, 28))
        }
        val title = TextView(this).apply {
            text = "Offline Music"
            textSize = 28f
            setTextColor(Color.WHITE)
        }
        status = TextView(this).apply {
            text = "Your music, offline."
            textSize = 15f
            setTextColor(Color.LTGRAY)
            setPadding(0, 12, 0, 18)
        }
        val add = Button(this).apply {
            text = "Import music"
            setOnClickListener { chooseMusic() }
        }
        val stop = Button(this).apply {
            text = "Stop playback"
            setOnClickListener { player?.stop(); player?.release(); player = null; status.text = "Playback stopped" }
        }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }
        root.addView(title)
        root.addView(status)
        root.addView(add)
        root.addView(stop)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun chooseMusic() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(intent, 1)
    }

    @Deprecated("Legacy callback used for simple document-picker handling")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 1 || resultCode != RESULT_OK || data == null) return
        data.clipData?.let { clip ->
            for (i in 0 until clip.itemCount) addTrack(clip.getItemAt(i).uri)
        } ?: data.data?.let { addTrack(it) }
    }

    private fun addTrack(uri: Uri) {
        if (tracks.contains(uri)) return
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        tracks.add(uri)
        val name = uri.lastPathSegment?.substringAfterLast('/') ?: "Audio track"
        val button = Button(this).apply {
            text = "▶  $name"
            setOnClickListener { play(uri, name) }
        }
        list.addView(button, LinearLayout.LayoutParams(-1, -2))
        status.text = "${tracks.size} track(s) imported"
    }

    private fun play(uri: Uri, name: String) {
        try {
            player?.stop(); player?.release()
            player = MediaPlayer().apply {
                setDataSource(this@MainActivity, uri)
                setOnPreparedListener { it.start(); status.text = "Playing: $name" }
                setOnCompletionListener { status.text = "Finished: $name" }
                setOnErrorListener { _, _, _ -> status.text = "Could not play this file"; true }
                prepareAsync()
            }
        } catch (e: Exception) { status.text = "Playback error: ${e.message}" }
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}
